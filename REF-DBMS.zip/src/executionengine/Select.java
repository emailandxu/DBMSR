
package executionengine;

public interface Select extends Operation {

}
