/*
 * Created on 2005-3-26
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package executionengine;


public interface Join extends Operation {

}
