package compiler;
/**
 * �߼���ѯ�ƻ�
 */
public class AlgebraPlan {
	private Algebra root;
	
	public AlgebraPlan(Algebra r){
		root = r;
	}
	public Algebra GetRoot(){
		return root;
	}
}

